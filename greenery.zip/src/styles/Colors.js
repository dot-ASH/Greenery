export const myColors = {
  light: '#E4E8D2',
  lightAlt: "#EAE3DB",
  dark: '#697454',
  darkAlt: "#0d2818",
  lightGreen: '#a3b18a',
  btnColor: "#9EA482",
  highText: '#344e41',
  errorText: '#bc4749',
  transDark: '#697454cc'
};