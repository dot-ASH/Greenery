
# Greenery
---

![image](assets/splashBanner.png)

An online plant care and delivery mobile application built with react native and supabase.js `ongoing`
